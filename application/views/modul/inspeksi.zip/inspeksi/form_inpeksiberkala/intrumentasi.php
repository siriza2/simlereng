  
 <div class="tab-content">
                   
     
		<div class="row">
		<div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Intrumentasi</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion2">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne1" aria-expanded="true" class="">
                        Inpeksi Awal / Sebelumnya
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne1" class="panel-collapse collapse in" aria-expanded="true" style="">
                    
					<div class="box-body">
                       <div class="box box-primary box-solid direct-chat direct-chat-primary">
             
			  
											  <div class="box-body">
												<!-- Conversations are loaded here -->
												
												<table class="table table-bordered">
												<tr>
												  
												  <th>Kondisi</th>
												  <th style="width: 80px">Dokumentasi</th>
												  
												</tr>
												
												<tr>
												  
												  <td>
											    <dl class="dl-horizontal">
												<dt><input type="checkbox"></dt>
												<dd>Baik</dd>
												<dt><input type="checkbox"></dt>
												<dd>Ada Kerusakan, masih berfungsi</dd>                
												<dt><input type="checkbox"></dt>
												<dd>Tidak Berfungsi</dd>
												</dl>
												
												</td>
												  
												  <td>
													<img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo"><br> <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">
												  </td>
												   
												</tr> 
												 
											  </table> 
											  
											  </div><!-- /.box-body -->
											  
											  <div class="box-footer">                 
											  </div><!-- /.box-footer-->
											</div>
													</div>
                  </div>
                </div>
                <div class="panel box box-danger">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo1" class="collapsed" aria-expanded="false">
                        Inspeksi Saat ini
                      </a>
                    </h4>
                  </div>
                  <div id="collapseTwo1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                    <div class="box-body">
                     
					 <div class="box box-primary box-solid direct-chat direct-chat-primary">
              <div class="box-header">
                <h3 class="box-title">Inpeksi Saat ini</h3>
                <div class="box-tools pull-right">
                  <!--<span data-toggle="tooltip" title="3 New Messages" class="badge bg-light-blue"></span>
                  <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  <button class="btn btn-box-tool" data-toggle="tooltip" title="Contacts" data-widget="chat-pane-toggle"><i class="fa fa-comments"></i></button>
                  <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>-->
                </div>
              </div><!-- /.box-header -->
			  
              <div class="box-body">
                <!-- Conversations are loaded here -->
				
				<table class="table table-bordered">
                <tr>
                  
                  <th>Kondisi</th>
                  <th style="width: 80px">Dokumentasi</th>
                  
                </tr>
                
				<tr>
                  
                  <td>
				  <dl class="dl-horizontal">
												<dt><input type="checkbox"></dt>
												<dd>Baik</dd>
												<dt><input type="checkbox"></dt>
												<dd>Ada Kerusakan, masih berfungsi</dd>                
												<dt><input type="checkbox"></dt>
												<dd>Tidak Berfungsi</dd>
												</dl>
				  </td>
                  
				  <td>
                    <!-- <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">-->
					 
                  <label for="exampleInputFile">File input</label>
                  <input id="exampleInputFile" type="file">
               
                  </td>
                   
                </tr>
                 
                
                 
              </table>
				
              
              </div><!-- /.box-body -->
			  
              <div class="box-footer">                 
              </div><!-- /.box-footer-->
            </div>
					 
                    </div>
                  </div>
                </div>
                 
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		 </div>
		
      
      
              
              
 </div>
 
  