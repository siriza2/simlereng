<div class="tab-content">
                   
     
		<div class="row">
		<div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Saluran di Kaki Lereng / Saluran Samping</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion2">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne2" aria-expanded="true" class="">
                        Inpeksi Awal / Sebelumnya
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne2" class="panel-collapse collapse in" aria-expanded="true" style="">
                    
					<div class="box-body">
                       <div class="box box-primary box-solid direct-chat direct-chat-primary">
             
			  
											  <div class="box-body">
												<!-- Conversations are loaded here -->
												
												<table class="table table-bordered">
												<tr>
												  
												  <th>Kondisi</th>
												  <th style="width: 80px">Dokumentasi</th>
												  
												</tr>
												
												<tr>
												  
												  <td>
												<dl class="dl-horizontal">
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
												
												<dt><input type="checkbox"></dt>
												<dd>Gompal</dd>
												<dd>Dimensi</dd>
												<dt><input type="checkbox"></dt>
												<dd>Retak</dd>
												<dd>Lebar Celah</dd>
												<dd>Panjang</dd>
												</dl>
												  </td>
												  
												  <td>
													<img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo"><br> <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">
												  </td>
												   
												</tr> 
												 
											  </table> 
											  
											  </div><!-- /.box-body -->
											  
											  <div class="box-footer">                 
											  </div><!-- /.box-footer-->
											</div>
													</div>
                  </div>
                </div>
                <div class="panel box box-danger">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo2" class="collapsed" aria-expanded="false">
                        Inspeksi Saat ini
                      </a>
                    </h4>
                  </div>
                  <div id="collapseTwo2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                    <div class="box-body">
                     
					 
              
			  
             
				
				<table class="table table-bordered">
                <tr>
                  
                  <th>Kondisi</th>
                  <th style="width: 80px">Dokumentasi</th>
                  
                </tr>
                
				<tr>
                  
                  <td>
				<dl class="dl-horizontal">
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
                
                <dt><input type="checkbox"></dt>
                <dd>Gompal</dd>
				<dd>Dimensi</dd>
                <dt><input type="checkbox"></dt>
                <dd>Retak</dd>
				<dd>Lebar Celah</dd>
				<dd>Panjang</dd>
                </dl>
				  </td>
                  
				  <td>
                    <!-- <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">-->
					 
                  <label for="exampleInputFile">File input</label>
                  <input id="exampleInputFile" type="file">
               
                  </td>
                   
                </tr>
                 
                
                 
              </table>
					 
                   
                  </div>
                </div>
                 
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		 </div>             
              
 </div>
 
 
   <!-- SALURAN GENDONG -->
		<div class="row">
		<div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Saloran Gendong</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion2">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne21" aria-expanded="true" class="">
                        Inpeksi Awal / Sebelumnya
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne21" class="panel-collapse collapse in" aria-expanded="true" style="">
                    
					<div class="box-body">
                       <div class="box box-primary box-solid direct-chat direct-chat-primary">
             
			  
											  <div class="box-body">
												<!-- Conversations are loaded here -->
												
												<table class="table table-bordered">
												<tr>
												  
												  <th>Kondisi</th>
												  <th style="width: 80px">Dokumentasi</th>
												  
												</tr>
												
												<tr>
												  
												  <td>
												<dl class="dl-horizontal">
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
												
												<dt><input type="checkbox"></dt>
												<dd>Gompal</dd>
												<dd>Dimensi</dd>
												<dt><input type="checkbox"></dt>
												<dd>Retak</dd>
												<dd>Lebar Celah</dd>
												<dd>Panjang</dd>
												</dl>
												  </td>
												  
												  <td>
													<img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo"><br> <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">
												  </td>
												   
												</tr> 
												 
											  </table> 
											  
											  </div><!-- /.box-body -->
											  
											  <div class="box-footer">                 
											  </div><!-- /.box-footer-->
											</div>
													</div>
                  </div>
                </div>
                <div class="panel box box-danger">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo21" class="collapsed" aria-expanded="false">
                        Inspeksi Saat ini
                      </a>
                    </h4>
                  </div>
                  <div id="collapseTwo21" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                    <div class="box-body">
                     
					 
              
			  
             
				
				<table class="table table-bordered">
                <tr>
                  
                  <th>Kondisi</th>
                  <th style="width: 80px">Dokumentasi</th>
                  
                </tr>
                
				<tr>
                  
                  <td>
				<dl class="dl-horizontal">
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
                
                <dt><input type="checkbox"></dt>
                <dd>Gompal</dd>
				<dd>Dimensi</dd>
                <dt><input type="checkbox"></dt>
                <dd>Retak</dd>
				<dd>Lebar Celah</dd>
				<dd>Panjang</dd>
                </dl>
				  </td>
                  
				  <td>
                    <!-- <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">-->
					 
                  <label for="exampleInputFile">File input</label>
                  <input id="exampleInputFile" type="file">
               
                  </td>
                   
                </tr>
                 
                
                 
              </table>
					 
                   
                  </div>
                </div>
                 
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		 </div>             
              
 </div>
 
 <!--   SALURAN TERJUNAN    -->
 <div class="row">
		<div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Saluran Terjunan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion2">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne211" aria-expanded="true" class="">
                        Inpeksi Awal / Sebelumnya
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne211" class="panel-collapse collapse in" aria-expanded="true" style="">
                    
					<div class="box-body">
                       <div class="box box-primary box-solid direct-chat direct-chat-primary">
             
			  
											  <div class="box-body">
												<!-- Conversations are loaded here -->
												
												<table class="table table-bordered">
												<tr>
												  
												  <th>Kondisi</th>
												  <th style="width: 80px">Dokumentasi</th>
												  
												</tr>
												
												<tr>
												  
												  <td>
												<dl class="dl-horizontal">
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
												<dt><input type="checkbox"></dt>
												<dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
												
												<dt><input type="checkbox"></dt>
												<dd>Gompal</dd>
												<dd>Dimensi</dd>
												<dt><input type="checkbox"></dt>
												<dd>Retak</dd>
												<dd>Lebar Celah</dd>
												<dd>Panjang</dd>
												</dl>
												  </td>
												  
												  <td>
													<img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo"><br> <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">
												  </td>
												   
												</tr> 
												 
											  </table> 
											  
											  </div><!-- /.box-body -->
											  
											  <div class="box-footer">                 
											  </div><!-- /.box-footer-->
											</div>
													</div>
                  </div>
                </div>
                <div class="panel box box-danger">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo211" class="collapsed" aria-expanded="false">
                        Inspeksi Saat ini
                      </a>
                    </h4>
                  </div>
                  <div id="collapseTwo211" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                    <div class="box-body">
                     
					 
              
			  
             
				
				<table class="table table-bordered">
                <tr>
                  
                  <th>Kondisi</th>
                  <th style="width: 80px">Dokumentasi</th>
                  
                </tr>
                
				<tr>
                  
                  <td>
				<dl class="dl-horizontal">
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir dan saluran bersih dari material penghambat seperti vegetasi/rumput liar, runtuhan, sampah dan material penghambat lainnya </dd>
                <dt><input type="checkbox"></dt>
                <dd>Air mengalir namun ada vegetasi seperti rumput liar dll.</dd>
                
                <dt><input type="checkbox"></dt>
                <dd>Gompal</dd>
				<dd>Dimensi</dd>
                <dt><input type="checkbox"></dt>
                <dd>Retak</dd>
				<dd>Lebar Celah</dd>
				<dd>Panjang</dd>
                </dl>
				  </td>
                  
				  <td>
                    <!-- <img class="img-responsive" src="<?php echo base_url('assets/adminlte/dist/img/photo4.jpg') ?>" alt="Photo">-->
					 
                  <label for="exampleInputFile">File input</label>
                  <input id="exampleInputFile" type="file">
               
                  </td>
                   
                </tr>
                 
                
                 
              </table>
					 
                   
                  </div>
                </div>
                 
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		 </div>             
              
 </div>
 
 
  </div>
 
  